-- إنشاء قاعدة البيانات
CREATE DATABASE IF NOT EXISTS onfire_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE onfire_db;

-- جدول المستخدمين
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
